# Find and Replace ionTheme_2 with your own value
# To generate the data we use this tool: http://www.json-generator.com/

Original color palette: http://paletton.com/#uid=7000u0kiCFn8GVde7NVmtwSqXtg

# You can find the documentation here: http://bit.ly/ionicthemes-theme1
